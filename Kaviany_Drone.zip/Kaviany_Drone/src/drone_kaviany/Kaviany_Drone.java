//Author Name: Angelo Kaviany
//Date: 8/30/2020
//Program Name: Kaviany_Drone
//Purpose: Simulation using button, drone movement in x, y, z location
package drone_kaviany;

import java.util.Scanner;

public class Kaviany_Drone {
	
//Initialize drone to starting coordinates of 0,0,0 and begin menu loop
	boolean exit;
	int x = 0, y= 0, z= 0;
	
	public static void main(String[] args) {
		Kaviany_Drone menu = new Kaviany_Drone();
		menu.runMenu();	
	}

//Menu loop	
	public void runMenu() {
		while(!exit){
			printMenu();
			int choice = getChoice();
			choiceAction(choice);
		}
	}
	
//Menu options
	private void printMenu() {
		System.out.println("Which direction would you like to move the drone?");
		System.out.println("1 - Move Up");
		System.out.println("2 - Move Down");
		System.out.println("3 - Move Forward");
		System.out.println("4 - Move Backward");
		System.out.println("5 - Turn Left");
		System.out.println("6 - Turn Right");
		System.out.println("7 - Display Position");
		System.out.println("8 - Exit Navigation");
	}

//Get user's choice for the menu
	private int getChoice() {
		Scanner input = new Scanner(System.in);
		int choice = -1;
		while(choice < 0 || choice > 8) {
			try {
				choice = Integer.parseInt(input.nextLine());
			}
			catch(Exception e) {
				System.out.println("You did not enter a valid choice, please try again.");
			}
		}
		return choice;
	}

//Perform movement for x y z	
	private void choiceAction(int choice) {
	switch(choice) {
	case 1:
		System.out.println("You have moved up");
		y = y + 1;
		break;
	case 2:
		System.out.println("You have moved down");
		y = y - 1;
		break;
	case 3:
		System.out.println("You have moved forward");
		z = z + 1;
		break;
	case 4:
		System.out.println("You have moved backward");
		z = z - 1;
		break;
	case 5:
		System.out.println("You have turned left");
		x = x -1;
		break;
	case 6:
		System.out.println("You have turned right");
		x = x + 1;
		break;
	case 7:
		System.out.println("Student_Drone [x_pos = " + x + ", y_pos = " + y + ", z_pos = " + z + "]");
		break;
	case 8:
		exit = true;
		break;
	default:
		System.out.println("Error");
		}
	}


}

